#ifndef _MEMORYACCESS_H
#define _MEMORYACCESS_H

extern void MemoryAccess();

#endif