#ifndef _WRITEBACK_H
#define _WRITEBACK_H

extern void WriteBack();

#endif