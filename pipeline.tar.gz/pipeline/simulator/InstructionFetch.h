#ifndef _INSTRUCTIONFETCH_H
#define _INSTRUCTIONFETCH_H

extern void InstructionFetch();

#endif